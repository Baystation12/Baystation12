<?php if (!defined('IN_PHPBB')) exit; $this->_tpl_include('overall_header.html'); if ($this->_rootref['MODE'] == ('success') || $this->_rootref['MODE'] == ('cancel')) {  ?>

	<h2><?php echo (isset($this->_rootref['SITENAME'])) ? $this->_rootref['SITENAME'] : ''; ?> :: <?php echo ((isset($this->_rootref['L_DONATION_TITLE'])) ? $this->_rootref['L_DONATION_TITLE'] : ((isset($user->lang['DONATION_TITLE'])) ? $user->lang['DONATION_TITLE'] : '{ DONATION_TITLE }')); ?></h2>
	<?php if ($this->_rootref['DONATION_BODY']) {  ?>

	<div class="panel">
		<div class="inner"><span class="corners-top"><span></span></span>
			<?php echo (isset($this->_rootref['DONATION_BODY'])) ? $this->_rootref['DONATION_BODY'] : ''; ?>

		<span class="corners-bottom"><span></span></span></div>
	</div>
	<?php } } else { if ($this->_rootref['S_SANDBOX']) {  ?>

		<h2><?php echo ((isset($this->_rootref['L_SANDBOX_TITLE'])) ? $this->_rootref['L_SANDBOX_TITLE'] : ((isset($user->lang['SANDBOX_TITLE'])) ? $user->lang['SANDBOX_TITLE'] : '{ SANDBOX_TITLE }')); ?></h2>
	<?php } else { ?>

		<h2><?php echo ((isset($this->_rootref['L_DONATION_TITLE_HEAD'])) ? $this->_rootref['L_DONATION_TITLE_HEAD'] : ((isset($user->lang['DONATION_TITLE_HEAD'])) ? $user->lang['DONATION_TITLE_HEAD'] : '{ DONATION_TITLE_HEAD }')); ?> <?php echo (isset($this->_rootref['SITENAME'])) ? $this->_rootref['SITENAME'] : ''; ?></h2>
	<?php } if ($this->_rootref['DONATION_BODY']) {  ?>

	<div class="panel">
		<div class="inner"><span class="corners-top"><span></span></span>
			<?php echo (isset($this->_rootref['DONATION_BODY'])) ? $this->_rootref['DONATION_BODY'] : ''; ?>

		<span class="corners-bottom"><span></span></span></div>
	</div>
	<?php } ?>


	<div class="panel">
		<div class="inner"><span class="corners-top"><span></span></span>
		<div class="center">
			<form action="<?php echo (isset($this->_rootref['S_DONATE_FORMS'])) ? $this->_rootref['S_DONATE_FORMS'] : ''; ?>" method="post">
				<div>
					<p><br /></p>
					<?php if ($this->_rootref['S_DONATION_DROPBOX']) {  ?>

					<select name="amount" id="amount"><?php echo (isset($this->_rootref['LIST_DONATION_VALUE'])) ? $this->_rootref['LIST_DONATION_VALUE'] : ''; ?></select>
					<?php } else { ?>

					<input type="text" name="amount" class="inputbox autowidth" value="<?php echo (isset($this->_rootref['DONATION_DEFAULT_VALUE'])) ? $this->_rootref['DONATION_DEFAULT_VALUE'] : ''; ?>"/>
					<?php } ?>

					<select name="currency_code" id="currency_code"><?php echo (isset($this->_rootref['LIST_DONATION_CURRENCY'])) ? $this->_rootref['LIST_DONATION_CURRENCY'] : ''; ?></select>
				</div>
				<p><br /></p>
				<fieldset id="contactpaypal" class="submit-buttons">
					<?php echo (isset($this->_rootref['S_HIDDEN_FIELDS'])) ? $this->_rootref['S_HIDDEN_FIELDS'] : ''; ?>

					<input type="image" src="<?php echo (isset($this->_rootref['T_IMAGESET_LANG_PATH'])) ? $this->_rootref['T_IMAGESET_LANG_PATH'] : ''; ?>/donate.gif" alt="<?php echo ((isset($this->_rootref['L_IMG_DONATE'])) ? $this->_rootref['L_IMG_DONATE'] : ((isset($user->lang['IMG_DONATE'])) ? $user->lang['IMG_DONATE'] : '{ IMG_DONATE }')); ?>" name="submit" onclick="JavaScript:document.getElementById('contactpaypal').style.display='none';document.getElementById('processingpaypal').style.display='block';" />
				</fieldset>
				<p><br /></p>
				<fieldset id="processingpaypal" class="loader submit-buttons">
					<img class="loader" src="<?php echo (isset($this->_rootref['T_IMAGES_PATH'])) ? $this->_rootref['T_IMAGES_PATH'] : ''; ?>donation/loader.gif" alt="<?php echo ((isset($this->_rootref['L_IMG_LOADER'])) ? $this->_rootref['L_IMG_LOADER'] : ((isset($user->lang['IMG_LOADER'])) ? $user->lang['IMG_LOADER'] : '{ IMG_LOADER }')); ?>" /> <input type="submit" class="button1" name="submit" value="<?php echo ((isset($this->_rootref['L_DONATION_CONTACT_PAYPAL'])) ? $this->_rootref['L_DONATION_CONTACT_PAYPAL'] : ((isset($user->lang['DONATION_CONTACT_PAYPAL'])) ? $user->lang['DONATION_CONTACT_PAYPAL'] : '{ DONATION_CONTACT_PAYPAL }')); ?>" />
				</fieldset>
			</form>
		</div>
		<span class="corners-bottom"><span></span></span></div>
	</div>

	<?php if ($this->_rootref['DONATION_GOAL_ENABLE'] || $this->_rootref['DONATION_RAISED_ENABLE'] || $this->_rootref['DONATION_USED_ENABLE']) {  ?>

	<div class="panel">
		<div class="inner"><span class="corners-top"><span></span></span>
			<?php $this->_tpl_include('donate/donate_stats.html'); ?>

		<span class="corners-bottom"><span></span></span></div>
	</div>
	<?php } } $this->_tpl_include('overall_footer.html'); ?>