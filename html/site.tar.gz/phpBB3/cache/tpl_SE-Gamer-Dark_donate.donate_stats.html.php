<?php if (!defined('IN_PHPBB')) exit; if ($this->_rootref['DONATION_STATS_INDEX_ENABLE']) {  if ($this->_rootref['U_DONATE']) {  ?><h3><a href="<?php echo (isset($this->_rootref['U_DONATE'])) ? $this->_rootref['U_DONATE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_DONATION_INDEX'])) ? $this->_rootref['L_DONATION_INDEX'] : ((isset($user->lang['DONATION_INDEX'])) ? $user->lang['DONATION_INDEX'] : '{ DONATION_INDEX }')); ?></a></h3><?php } else { ?><h3><?php echo ((isset($this->_rootref['L_DONATION_INDEX'])) ? $this->_rootref['L_DONATION_INDEX'] : ((isset($user->lang['DONATION_INDEX'])) ? $user->lang['DONATION_INDEX'] : '{ DONATION_INDEX }')); ?></h3><?php } } if ($this->_rootref['S_GOAL_NUMBER']) {  ?>

	<div class="prog_grey"><div class="prog_green" style="width:<?php echo (isset($this->_rootref['DONATION_GOAL_NUMBER'])) ? $this->_rootref['DONATION_GOAL_NUMBER'] : ''; ?>%;"><span class="progress"><?php echo (isset($this->_rootref['DONATION_GOAL_NUMBER'])) ? $this->_rootref['DONATION_GOAL_NUMBER'] : ''; ?>%</span></div></div>
<?php } ?>


<p class="donation_stats">
	<?php if ($this->_rootref['DONATION_RAISED_ENABLE']) {  ?>

		<?php echo ((isset($this->_rootref['L_DONATION_RAISED'])) ? $this->_rootref['L_DONATION_RAISED'] : ((isset($user->lang['DONATION_RAISED'])) ? $user->lang['DONATION_RAISED'] : '{ DONATION_RAISED }')); if ($this->_rootref['DONATION_USED_ENABLE']) {  ?><br /><?php } } if ($this->_rootref['DONATION_GOAL_ENABLE']) {  ?>

		<?php echo ((isset($this->_rootref['L_DONATION_GOAL'])) ? $this->_rootref['L_DONATION_GOAL'] : ((isset($user->lang['DONATION_GOAL'])) ? $user->lang['DONATION_GOAL'] : '{ DONATION_GOAL }')); ?><br />
	<?php } if ($this->_rootref['S_USED_NUMBER']) {  ?>

</p>
<div class="prog_grey"><div class="prog_red" style="width:<?php echo (isset($this->_rootref['DONATION_USED_NUMBER'])) ? $this->_rootref['DONATION_USED_NUMBER'] : ''; ?>%;"><span class="progress"><?php echo (isset($this->_rootref['DONATION_USED_NUMBER'])) ? $this->_rootref['DONATION_USED_NUMBER'] : ''; ?>%</span></div></div>
<p class="donation_stats">
<?php } if ($this->_rootref['DONATION_USED_ENABLE']) {  ?>

				<?php echo ((isset($this->_rootref['L_DONATION_USED'])) ? $this->_rootref['L_DONATION_USED'] : ((isset($user->lang['DONATION_USED'])) ? $user->lang['DONATION_USED'] : '{ DONATION_USED }')); ?>

	<?php } ?>

</p>