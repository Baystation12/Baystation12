<?php if (!defined('IN_PHPBB')) exit; ?></div>
	<div class="clear"></div>

	</div>
	<span class="corners-bottom"><span></span></span></div>
</div>

<?php $this->_tpl_include('overall_footer.html'); ?>