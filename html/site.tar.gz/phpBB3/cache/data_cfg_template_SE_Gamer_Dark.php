<?php exit; ?>
1408859156
209
a:5:{s:4:"name";s:13:"SE Gamer Dark";s:9:"copyright";s:57:"&copy; Premium phpBB3 Styles (http://www.bbcustomize.com)";s:7:"version";s:5:"1.0.0";s:12:"inherit_from";s:9:"prosilver";s:8:"filetime";i:1374824626;}