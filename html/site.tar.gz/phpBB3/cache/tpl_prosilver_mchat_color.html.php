<?php if (!defined('IN_PHPBB')) exit; ?><div id="mChatColour" style="display: none; text-align: center">
						<table width="50%" style="margin-left: auto; margin-right: auto;">
							<tr align="center">
								<td valign="top">
									<script type="text/javascript">
									// <![CDATA[
										colorPalette('h', 15, 10);
									// ]]>
									</script>
								</td>
							</tr>
						</table>
					</div>