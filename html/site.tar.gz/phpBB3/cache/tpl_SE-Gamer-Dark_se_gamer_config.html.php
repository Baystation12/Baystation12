<?php if (!defined('IN_PHPBB')) exit; ?><!--

Full feature instructions can be found on the SE Gamer "FAQ" tab at:
https://www.phpbb.com/customise/db/style/se_gamer_light

<?php $this->_tpldata['DEFINE']['.']['BOARD_WIDTH'] = '80%'; ?> Options: Any % | Any 'px' value not below 900px
<?php $this->_tpldata['DEFINE']['.']['MAX_BOARD_WIDTH'] = '1400px'; ?> Only use if board width is a percentage. See ReadMe file for details
<?php $this->_tpldata['DEFINE']['.']['LOGO_TYPE'] = 'logo'; ?> Options: Logo | Text
<?php $this->_tpldata['DEFINE']['.']['LOGO_POSITION'] = 'left'; ?> Options: Left | Center | Right
<?php $this->_tpldata['DEFINE']['.']['SHOW_SEARCH_IN_NAV'] = 'yes'; ?> Options: Yes | No
<?php $this->_tpldata['DEFINE']['.']['COLLAPSIBLE_CATEGORIES'] = 'on'; ?> Options: On | Off
<?php $this->_tpldata['DEFINE']['.']['MODERATOR_COLUMN_ON_INDEX'] = 'no'; ?> Options: Yes | No (won't work if both sidebars are enabled)
<?php $this->_tpldata['DEFINE']['.']['SIDEBARS'] = 'off'; ?> Options: Left | Right | Both | Off
<?php $this->_tpldata['DEFINE']['.']['SIDEBAR_ON_PAGES'] = 'index'; ?> Options: Global | Index
<?php $this->_tpldata['DEFINE']['.']['PROFILE_SIDE'] = 'left'; ?>

-->