<?php exit; ?>
1408859156
199
a:5:{s:4:"name";s:13:"SE Gamer Dark";s:9:"copyright";s:57:"&copy; Premium phpBB3 Styles (http://www.bbcustomize.com)";s:7:"version";s:5:"1.0.0";s:14:"parse_css_file";b:1;s:8:"filetime";i:1374824626;}