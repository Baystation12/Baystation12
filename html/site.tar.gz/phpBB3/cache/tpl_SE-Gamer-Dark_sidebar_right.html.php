<?php if (!defined('IN_PHPBB')) exit; ?><a class="ad1" href="#"><img src="<?php echo (isset($this->_rootref['T_THEME_PATH'])) ? $this->_rootref['T_THEME_PATH'] : ''; ?>/images/125x125.gif" width="125" height="125" alt="" /></a>
<a class="ad2" href="#"><img src="<?php echo (isset($this->_rootref['T_THEME_PATH'])) ? $this->_rootref['T_THEME_PATH'] : ''; ?>/images/125x125.gif" width="125" height="125" alt="" /></a>
<a class="ad1" href="#"><img src="<?php echo (isset($this->_rootref['T_THEME_PATH'])) ? $this->_rootref['T_THEME_PATH'] : ''; ?>/images/125x125.gif" width="125" height="125" alt="" /></a>
<a class="ad2" href="#"><img src="<?php echo (isset($this->_rootref['T_THEME_PATH'])) ? $this->_rootref['T_THEME_PATH'] : ''; ?>/images/125x125.gif" width="125" height="125" alt="" /></a>

<br />

<div style="text-align: center;">
	<img src="<?php echo (isset($this->_rootref['T_THEME_PATH'])) ? $this->_rootref['T_THEME_PATH'] : ''; ?>/images/250x250.gif" width="250" height="250" alt="" />
</div>