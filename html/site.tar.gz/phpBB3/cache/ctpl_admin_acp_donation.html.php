<?php if (!defined('IN_PHPBB')) exit; $this->_tpl_include('overall_header.html'); if ($this->_rootref['S_OVERVIEW']) {  ?>
	<h1><?php echo ((isset($this->_rootref['L_DONATION_WELCOME'])) ? $this->_rootref['L_DONATION_WELCOME'] : ((isset($user->lang['DONATION_WELCOME'])) ? $user->lang['DONATION_WELCOME'] : '{ DONATION_WELCOME }')); ?></h1>

	<p><?php echo ((isset($this->_rootref['L_DONATION_WELCOME_EXPLAIN'])) ? $this->_rootref['L_DONATION_WELCOME_EXPLAIN'] : ((isset($user->lang['DONATION_WELCOME_EXPLAIN'])) ? $user->lang['DONATION_WELCOME_EXPLAIN'] : '{ DONATION_WELCOME_EXPLAIN }')); ?></p>

	<?php if ($this->_rootref['S_DONATION_VERSIONCHECK_FAIL']) {  ?>
		<div class="errorbox notice">
			<p><?php echo ((isset($this->_rootref['L_VERSIONCHECK_FAIL'])) ? $this->_rootref['L_VERSIONCHECK_FAIL'] : ((isset($user->lang['VERSIONCHECK_FAIL'])) ? $user->lang['VERSIONCHECK_FAIL'] : '{ VERSIONCHECK_FAIL }')); ?></p>
			<p><a href="<?php echo (isset($this->_rootref['U_DONATION_VERSIONCHECK_FORCE'])) ? $this->_rootref['U_DONATION_VERSIONCHECK_FORCE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'])) ? $this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'] : ((isset($user->lang['VERSIONCHECK_FORCE_UPDATE'])) ? $user->lang['VERSIONCHECK_FORCE_UPDATE'] : '{ VERSIONCHECK_FORCE_UPDATE }')); ?></a></p>
		</div>
	<?php } else if (! $this->_rootref['S_DONATION_VERSION_UP_TO_DATE']) {  ?>
		<div class="errorbox">
			<p><?php echo ((isset($this->_rootref['L_DONATION_VERSION_NOT_UP_TO_DATE_TITLE'])) ? $this->_rootref['L_DONATION_VERSION_NOT_UP_TO_DATE_TITLE'] : ((isset($user->lang['DONATION_VERSION_NOT_UP_TO_DATE_TITLE'])) ? $user->lang['DONATION_VERSION_NOT_UP_TO_DATE_TITLE'] : '{ DONATION_VERSION_NOT_UP_TO_DATE_TITLE }')); ?></p>
			<p><a href="<?php echo (isset($this->_rootref['U_DONATION_VERSIONCHECK_FORCE'])) ? $this->_rootref['U_DONATION_VERSIONCHECK_FORCE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'])) ? $this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'] : ((isset($user->lang['VERSIONCHECK_FORCE_UPDATE'])) ? $user->lang['VERSIONCHECK_FORCE_UPDATE'] : '{ VERSIONCHECK_FORCE_UPDATE }')); ?></a> &middot; <a href="<?php echo (isset($this->_rootref['U_DONATION_VERSIONCHECK'])) ? $this->_rootref['U_DONATION_VERSIONCHECK'] : ''; ?>"><?php echo ((isset($this->_rootref['L_MORE_INFORMATION'])) ? $this->_rootref['L_MORE_INFORMATION'] : ((isset($user->lang['MORE_INFORMATION'])) ? $user->lang['MORE_INFORMATION'] : '{ MORE_INFORMATION }')); ?></a></p>
		</div>
	<?php } ?>

	<table cellspacing="1">
		<caption><?php echo ((isset($this->_rootref['L_DONATION_STATS'])) ? $this->_rootref['L_DONATION_STATS'] : ((isset($user->lang['DONATION_STATS'])) ? $user->lang['DONATION_STATS'] : '{ DONATION_STATS }')); ?></caption>
		<col class="col1" /><col class="col2" /><col class="col1" /><col class="col2" />
		<thead>
			<tr>
				<th><?php echo ((isset($this->_rootref['L_STATISTIC'])) ? $this->_rootref['L_STATISTIC'] : ((isset($user->lang['STATISTIC'])) ? $user->lang['STATISTIC'] : '{ STATISTIC }')); ?></th>
				<th><?php echo ((isset($this->_rootref['L_VALUE'])) ? $this->_rootref['L_VALUE'] : ((isset($user->lang['VALUE'])) ? $user->lang['VALUE'] : '{ VALUE }')); ?></th>
				<th><?php echo ((isset($this->_rootref['L_STATISTIC'])) ? $this->_rootref['L_STATISTIC'] : ((isset($user->lang['STATISTIC'])) ? $user->lang['STATISTIC'] : '{ STATISTIC }')); ?></th>
				<th><?php echo ((isset($this->_rootref['L_VALUE'])) ? $this->_rootref['L_VALUE'] : ((isset($user->lang['VALUE'])) ? $user->lang['VALUE'] : '{ VALUE }')); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><?php echo ((isset($this->_rootref['L_DONATION_INSTALL_DATE'])) ? $this->_rootref['L_DONATION_INSTALL_DATE'] : ((isset($user->lang['DONATION_INSTALL_DATE'])) ? $user->lang['DONATION_INSTALL_DATE'] : '{ DONATION_INSTALL_DATE }')); ?>: </td>
				<td><strong><?php echo (isset($this->_rootref['DONATION_INSTALL_DATE'])) ? $this->_rootref['DONATION_INSTALL_DATE'] : ''; ?></strong></td>
				<td><?php echo ((isset($this->_rootref['L_INFO_CURL'])) ? $this->_rootref['L_INFO_CURL'] : ((isset($user->lang['INFO_CURL'])) ? $user->lang['INFO_CURL'] : '{ INFO_CURL }')); ?>: </td>
				<td><strong <?php if ($this->_rootref['S_CURL']) {  ?>style="color: #228822;"<?php } else { ?>style="color: #BC2A4D;"<?php } ?>><?php echo (isset($this->_rootref['INFO_CURL'])) ? $this->_rootref['INFO_CURL'] : ''; ?></strong></td>
			</tr>
			<tr>
				<td><?php echo ((isset($this->_rootref['L_DONATION_VERSION'])) ? $this->_rootref['L_DONATION_VERSION'] : ((isset($user->lang['DONATION_VERSION'])) ? $user->lang['DONATION_VERSION'] : '{ DONATION_VERSION }')); ?>: </td>
				<td>
				<?php if ($this->_rootref['S_DONATION_VERSION_UP_TO_DATE']) {  ?>
					<strong style="color: #228822;"><?php echo (isset($this->_rootref['DONATION_VERSION'])) ? $this->_rootref['DONATION_VERSION'] : ''; ?></strong> [&nbsp;<a href="<?php echo (isset($this->_rootref['U_DONATION_VERSIONCHECK_FORCE'])) ? $this->_rootref['U_DONATION_VERSIONCHECK_FORCE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'])) ? $this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'] : ((isset($user->lang['VERSIONCHECK_FORCE_UPDATE'])) ? $user->lang['VERSIONCHECK_FORCE_UPDATE'] : '{ VERSIONCHECK_FORCE_UPDATE }')); ?></a>&nbsp;]
				<?php } else { ?>
					<strong><a href="<?php echo (isset($this->_rootref['U_DONATION_VERSIONCHECK'])) ? $this->_rootref['U_DONATION_VERSIONCHECK'] : ''; ?>" style="color: #BC2A4D;" title="<?php echo ((isset($this->_rootref['L_MORE_INFORMATION'])) ? $this->_rootref['L_MORE_INFORMATION'] : ((isset($user->lang['MORE_INFORMATION'])) ? $user->lang['MORE_INFORMATION'] : '{ MORE_INFORMATION }')); ?>"><?php echo (isset($this->_rootref['DONATION_VERSION'])) ? $this->_rootref['DONATION_VERSION'] : ''; ?></a></strong> [&nbsp;<a href="<?php echo (isset($this->_rootref['U_DONATION_VERSIONCHECK_FORCE'])) ? $this->_rootref['U_DONATION_VERSIONCHECK_FORCE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'])) ? $this->_rootref['L_VERSIONCHECK_FORCE_UPDATE'] : ((isset($user->lang['VERSIONCHECK_FORCE_UPDATE'])) ? $user->lang['VERSIONCHECK_FORCE_UPDATE'] : '{ VERSIONCHECK_FORCE_UPDATE }')); ?></a>&nbsp;]
				<?php } ?>
				</td>
				<td><?php echo ((isset($this->_rootref['L_INFO_FSOCKOPEN'])) ? $this->_rootref['L_INFO_FSOCKOPEN'] : ((isset($user->lang['INFO_FSOCKOPEN'])) ? $user->lang['INFO_FSOCKOPEN'] : '{ INFO_FSOCKOPEN }')); ?>: </td>
				<td><strong <?php if ($this->_rootref['S_FSOCKOPEN']) {  ?>style="color: #228822;"<?php } else { ?>style="color: #BC2A4D;"<?php } ?>><?php echo (isset($this->_rootref['INFO_FSOCKOPEN'])) ? $this->_rootref['INFO_FSOCKOPEN'] : ''; ?></strong></td>
			</tr>
		</tbody>
	</table>

	<?php if ($this->_rootref['S_ACTION_OPTIONS']) {  ?>
		<fieldset>
			<legend><?php echo ((isset($this->_rootref['L_STATISTIC_RESYNC_OPTIONS'])) ? $this->_rootref['L_STATISTIC_RESYNC_OPTIONS'] : ((isset($user->lang['STATISTIC_RESYNC_OPTIONS'])) ? $user->lang['STATISTIC_RESYNC_OPTIONS'] : '{ STATISTIC_RESYNC_OPTIONS }')); ?></legend>

			<form id="action_date_form" method="post" action="<?php echo (isset($this->_rootref['U_ACTION'])) ? $this->_rootref['U_ACTION'] : ''; ?>">
				<dl>
					<dt><label for="action_date"><?php echo ((isset($this->_rootref['L_STAT_RESET_DATE'])) ? $this->_rootref['L_STAT_RESET_DATE'] : ((isset($user->lang['STAT_RESET_DATE'])) ? $user->lang['STAT_RESET_DATE'] : '{ STAT_RESET_DATE }')); ?></label><br /><span><?php echo ((isset($this->_rootref['L_STAT_RESET_DATE_EXPLAIN'])) ? $this->_rootref['L_STAT_RESET_DATE_EXPLAIN'] : ((isset($user->lang['STAT_RESET_DATE_EXPLAIN'])) ? $user->lang['STAT_RESET_DATE_EXPLAIN'] : '{ STAT_RESET_DATE_EXPLAIN }')); ?></span></dt>
					<dd><input type="hidden" name="action" value="date" /><input class="button2" type="submit" id="action_date" name="action_date" value="<?php echo ((isset($this->_rootref['L_RUN'])) ? $this->_rootref['L_RUN'] : ((isset($user->lang['RUN'])) ? $user->lang['RUN'] : '{ RUN }')); ?>" /></dd>
				</dl>
			</form>
		</fieldset>
	<?php } } if ($this->_rootref['S_DONATION_PAGES']) {  if ($this->_rootref['S_EDIT_DP']) {  if ($this->_rootref['S_ERROR']) {  ?>
			<div class="errorbox">
				<h3><?php echo ((isset($this->_rootref['L_WARNING'])) ? $this->_rootref['L_WARNING'] : ((isset($user->lang['WARNING'])) ? $user->lang['WARNING'] : '{ WARNING }')); ?></h3>
				<p><?php echo (isset($this->_rootref['ERROR_MSG'])) ? $this->_rootref['ERROR_MSG'] : ''; ?></p>
			</div>
		<?php } ?>
		<a href="<?php echo (isset($this->_rootref['U_ACTION'])) ? $this->_rootref['U_ACTION'] : ''; ?>" style="float: <?php echo (isset($this->_rootref['S_CONTENT_FLOW_END'])) ? $this->_rootref['S_CONTENT_FLOW_END'] : ''; ?>;">&laquo; <?php echo ((isset($this->_rootref['L_BACK'])) ? $this->_rootref['L_BACK'] : ((isset($user->lang['BACK'])) ? $user->lang['BACK'] : '{ BACK }')); ?></a>
		<h1><?php echo ((isset($this->_rootref['L_TITLE'])) ? $this->_rootref['L_TITLE'] : ((isset($user->lang['TITLE'])) ? $user->lang['TITLE'] : '{ TITLE }')); ?></h1>
		<p><?php echo ((isset($this->_rootref['L_TITLE_EXPLAIN'])) ? $this->_rootref['L_TITLE_EXPLAIN'] : ((isset($user->lang['TITLE_EXPLAIN'])) ? $user->lang['TITLE_EXPLAIN'] : '{ TITLE_EXPLAIN }')); ?></p>
		<script type="text/javascript">
		// <![CDATA[
			var form_name = 'acp_donation';
			var text_name = 'input_pages';

			// Define the bbCode tags
			var bbcode = new Array();
			var bbtags = new Array('[b]','[/b]','[i]','[/i]','[u]','[/u]','[quote]','[/quote]','[code]','[/code]','[list]','[/list]','[list=]','[/list]','[img]','[/img]','[url]','[/url]','[flash=]', '[/flash]','[size=]','[/size]'<?php $_custom_tags_count = (isset($this->_tpldata['custom_tags'])) ? sizeof($this->_tpldata['custom_tags']) : 0;if ($_custom_tags_count) {for ($_custom_tags_i = 0; $_custom_tags_i < $_custom_tags_count; ++$_custom_tags_i){$_custom_tags_val = &$this->_tpldata['custom_tags'][$_custom_tags_i]; ?>, <?php echo $_custom_tags_val['BBCODE_NAME']; }} ?>);
			var imageTag = false;

			// Helpline messages
			var help_line = {
				b: '<?php echo ((isset($this->_rootref['LA_BBCODE_B_HELP'])) ? $this->_rootref['LA_BBCODE_B_HELP'] : ((isset($this->_rootref['L_BBCODE_B_HELP'])) ? addslashes($this->_rootref['L_BBCODE_B_HELP']) : ((isset($user->lang['BBCODE_B_HELP'])) ? addslashes($user->lang['BBCODE_B_HELP']) : '{ BBCODE_B_HELP }'))); ?>',
				i: '<?php echo ((isset($this->_rootref['LA_BBCODE_I_HELP'])) ? $this->_rootref['LA_BBCODE_I_HELP'] : ((isset($this->_rootref['L_BBCODE_I_HELP'])) ? addslashes($this->_rootref['L_BBCODE_I_HELP']) : ((isset($user->lang['BBCODE_I_HELP'])) ? addslashes($user->lang['BBCODE_I_HELP']) : '{ BBCODE_I_HELP }'))); ?>',
				u: '<?php echo ((isset($this->_rootref['LA_BBCODE_U_HELP'])) ? $this->_rootref['LA_BBCODE_U_HELP'] : ((isset($this->_rootref['L_BBCODE_U_HELP'])) ? addslashes($this->_rootref['L_BBCODE_U_HELP']) : ((isset($user->lang['BBCODE_U_HELP'])) ? addslashes($user->lang['BBCODE_U_HELP']) : '{ BBCODE_U_HELP }'))); ?>',
				q: '<?php echo ((isset($this->_rootref['LA_BBCODE_Q_HELP'])) ? $this->_rootref['LA_BBCODE_Q_HELP'] : ((isset($this->_rootref['L_BBCODE_Q_HELP'])) ? addslashes($this->_rootref['L_BBCODE_Q_HELP']) : ((isset($user->lang['BBCODE_Q_HELP'])) ? addslashes($user->lang['BBCODE_Q_HELP']) : '{ BBCODE_Q_HELP }'))); ?>',
				c: '<?php echo ((isset($this->_rootref['LA_BBCODE_C_HELP'])) ? $this->_rootref['LA_BBCODE_C_HELP'] : ((isset($this->_rootref['L_BBCODE_C_HELP'])) ? addslashes($this->_rootref['L_BBCODE_C_HELP']) : ((isset($user->lang['BBCODE_C_HELP'])) ? addslashes($user->lang['BBCODE_C_HELP']) : '{ BBCODE_C_HELP }'))); ?>',
				l: '<?php echo ((isset($this->_rootref['LA_BBCODE_L_HELP'])) ? $this->_rootref['LA_BBCODE_L_HELP'] : ((isset($this->_rootref['L_BBCODE_L_HELP'])) ? addslashes($this->_rootref['L_BBCODE_L_HELP']) : ((isset($user->lang['BBCODE_L_HELP'])) ? addslashes($user->lang['BBCODE_L_HELP']) : '{ BBCODE_L_HELP }'))); ?>',
				o: '<?php echo ((isset($this->_rootref['LA_BBCODE_O_HELP'])) ? $this->_rootref['LA_BBCODE_O_HELP'] : ((isset($this->_rootref['L_BBCODE_O_HELP'])) ? addslashes($this->_rootref['L_BBCODE_O_HELP']) : ((isset($user->lang['BBCODE_O_HELP'])) ? addslashes($user->lang['BBCODE_O_HELP']) : '{ BBCODE_O_HELP }'))); ?>',
				p: '<?php echo ((isset($this->_rootref['LA_BBCODE_P_HELP'])) ? $this->_rootref['LA_BBCODE_P_HELP'] : ((isset($this->_rootref['L_BBCODE_P_HELP'])) ? addslashes($this->_rootref['L_BBCODE_P_HELP']) : ((isset($user->lang['BBCODE_P_HELP'])) ? addslashes($user->lang['BBCODE_P_HELP']) : '{ BBCODE_P_HELP }'))); ?>',
				w: '<?php echo ((isset($this->_rootref['LA_BBCODE_W_HELP'])) ? $this->_rootref['LA_BBCODE_W_HELP'] : ((isset($this->_rootref['L_BBCODE_W_HELP'])) ? addslashes($this->_rootref['L_BBCODE_W_HELP']) : ((isset($user->lang['BBCODE_W_HELP'])) ? addslashes($user->lang['BBCODE_W_HELP']) : '{ BBCODE_W_HELP }'))); ?>',
				s: '<?php echo ((isset($this->_rootref['LA_BBCODE_S_HELP'])) ? $this->_rootref['LA_BBCODE_S_HELP'] : ((isset($this->_rootref['L_BBCODE_S_HELP'])) ? addslashes($this->_rootref['L_BBCODE_S_HELP']) : ((isset($user->lang['BBCODE_S_HELP'])) ? addslashes($user->lang['BBCODE_S_HELP']) : '{ BBCODE_S_HELP }'))); ?>',
				f: '<?php echo ((isset($this->_rootref['LA_BBCODE_F_HELP'])) ? $this->_rootref['LA_BBCODE_F_HELP'] : ((isset($this->_rootref['L_BBCODE_F_HELP'])) ? addslashes($this->_rootref['L_BBCODE_F_HELP']) : ((isset($user->lang['BBCODE_F_HELP'])) ? addslashes($user->lang['BBCODE_F_HELP']) : '{ BBCODE_F_HELP }'))); ?>',
				y: '<?php echo ((isset($this->_rootref['LA_BBCODE_Y_HELP'])) ? $this->_rootref['LA_BBCODE_Y_HELP'] : ((isset($this->_rootref['L_BBCODE_Y_HELP'])) ? addslashes($this->_rootref['L_BBCODE_Y_HELP']) : ((isset($user->lang['BBCODE_Y_HELP'])) ? addslashes($user->lang['BBCODE_Y_HELP']) : '{ BBCODE_Y_HELP }'))); ?>',
				d: '<?php echo ((isset($this->_rootref['LA_BBCODE_D_HELP'])) ? $this->_rootref['LA_BBCODE_D_HELP'] : ((isset($this->_rootref['L_BBCODE_D_HELP'])) ? addslashes($this->_rootref['L_BBCODE_D_HELP']) : ((isset($user->lang['BBCODE_D_HELP'])) ? addslashes($user->lang['BBCODE_D_HELP']) : '{ BBCODE_D_HELP }'))); ?>',
				tip: '<?php echo ((isset($this->_rootref['L_STYLES_TIP'])) ? $this->_rootref['L_STYLES_TIP'] : ((isset($user->lang['STYLES_TIP'])) ? $user->lang['STYLES_TIP'] : '{ STYLES_TIP }')); ?>'
				<?php $_custom_tags_count = (isset($this->_tpldata['custom_tags'])) ? sizeof($this->_tpldata['custom_tags']) : 0;if ($_custom_tags_count) {for ($_custom_tags_i = 0; $_custom_tags_i < $_custom_tags_count; ++$_custom_tags_i){$_custom_tags_val = &$this->_tpldata['custom_tags'][$_custom_tags_i]; ?>
					,cb_<?php echo $_custom_tags_val['BBCODE_ID']; ?>: '<?php echo $_custom_tags_val['A_BBCODE_HELPLINE']; ?>'
				<?php }} ?>
			}
		// ]]>
		</script>
		<script type="text/javascript" src="<?php echo (isset($this->_rootref['T_TEMPLATE_PATH'])) ? $this->_rootref['T_TEMPLATE_PATH'] : ''; ?>/editor.js"></script>

		<form id="acp_donation" method="post" action="<?php echo (isset($this->_rootref['U_ACTION'])) ? $this->_rootref['U_ACTION'] : ''; ?>">
		<?php if ($this->_rootref['DONATION_DRAFT_PREVIEW']) {  ?>
			<fieldset>
				<legend><?php echo ((isset($this->_rootref['L_PREVIEW'])) ? $this->_rootref['L_PREVIEW'] : ((isset($user->lang['PREVIEW'])) ? $user->lang['PREVIEW'] : '{ PREVIEW }')); ?></legend>
				<p><?php echo (isset($this->_rootref['DONATION_DRAFT_PREVIEW'])) ? $this->_rootref['DONATION_DRAFT_PREVIEW'] : ''; ?></p>
			</fieldset>
		<?php } ?>

			<fieldset>
				<legend><?php echo ((isset($this->_rootref['L_DONATION_PAGES_TITLE'])) ? $this->_rootref['L_DONATION_PAGES_TITLE'] : ((isset($user->lang['DONATION_PAGES_TITLE'])) ? $user->lang['DONATION_PAGES_TITLE'] : '{ DONATION_PAGES_TITLE }')); ?></legend>
				<p><?php echo ((isset($this->_rootref['L_DONATION_PAGES_TITLE_EXPLAIN'])) ? $this->_rootref['L_DONATION_PAGES_TITLE_EXPLAIN'] : ((isset($user->lang['DONATION_PAGES_TITLE_EXPLAIN'])) ? $user->lang['DONATION_PAGES_TITLE_EXPLAIN'] : '{ DONATION_PAGES_TITLE_EXPLAIN }')); ?></p>

				<div id="format-buttons">
					<input type="button" class="button2" accesskey="b" name="addbbcode0" value=" B " style="font-weight:bold; width: 30px;" onclick="bbstyle(0)" onmouseover="helpline('b')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="i" name="addbbcode2" value=" i " style="font-style:italic; width: 30px;" onclick="bbstyle(2)" onmouseover="helpline('i')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="u" name="addbbcode4" value=" u " style="text-decoration: underline; width: 30px;" onclick="bbstyle(4)" onmouseover="helpline('u')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="q" name="addbbcode6" value="Quote" style="width: 50px" onclick="bbstyle(6)" onmouseover="helpline('q')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="c" name="addbbcode8" value="Code" style="width: 40px" onclick="bbstyle(8)" onmouseover="helpline('c')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="l" name="addbbcode10" value="List" style="width: 40px" onclick="bbstyle(10)" onmouseover="helpline('l')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="o" name="addbbcode12" value="List=" style="width: 40px" onclick="bbstyle(12)" onmouseover="helpline('o')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="y" name="addlistitem" value="[*]" style="width: 40px" onclick="bbstyle(-1)" onmouseover="helpline('y')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="p" name="addbbcode14" value="Img" style="width: 40px" onclick="bbstyle(14)" onmouseover="helpline('p')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="w" name="addbbcode16" value="URL" style="text-decoration: underline; width: 40px" onclick="bbstyle(16)" onmouseover="helpline('w')" onmouseout="helpline('tip')" />
					<input type="button" class="button2" accesskey="d" name="addbbcode18" value="Flash" onclick="bbstyle(18)" onmouseover="helpline('d')" onmouseout="helpline('tip')" />

					<?php echo ((isset($this->_rootref['L_FONT_SIZE'])) ? $this->_rootref['L_FONT_SIZE'] : ((isset($user->lang['FONT_SIZE'])) ? $user->lang['FONT_SIZE'] : '{ FONT_SIZE }')); ?>: <select name="addbbcode20" onchange="bbfontstyle('[size=' + this.form.addbbcode20.options[this.form.addbbcode20.selectedIndex].value + ']', '[/size]');this.form.addbbcode20.selectedIndex = 2;" title="<?php echo ((isset($this->_rootref['L_FONT_SIZE'])) ? $this->_rootref['L_FONT_SIZE'] : ((isset($user->lang['FONT_SIZE'])) ? $user->lang['FONT_SIZE'] : '{ FONT_SIZE }')); ?>" onmouseover="helpline('f')" onmouseout="helpline('tip')">
						<option value="50"><?php echo ((isset($this->_rootref['L_FONT_TINY'])) ? $this->_rootref['L_FONT_TINY'] : ((isset($user->lang['FONT_TINY'])) ? $user->lang['FONT_TINY'] : '{ FONT_TINY }')); ?></option>
						<option value="85"><?php echo ((isset($this->_rootref['L_FONT_SMALL'])) ? $this->_rootref['L_FONT_SMALL'] : ((isset($user->lang['FONT_SMALL'])) ? $user->lang['FONT_SMALL'] : '{ FONT_SMALL }')); ?></option>
						<option value="100" selected="selected"><?php echo ((isset($this->_rootref['L_FONT_NORMAL'])) ? $this->_rootref['L_FONT_NORMAL'] : ((isset($user->lang['FONT_NORMAL'])) ? $user->lang['FONT_NORMAL'] : '{ FONT_NORMAL }')); ?></option>
						<option value="150"><?php echo ((isset($this->_rootref['L_FONT_LARGE'])) ? $this->_rootref['L_FONT_LARGE'] : ((isset($user->lang['FONT_LARGE'])) ? $user->lang['FONT_LARGE'] : '{ FONT_LARGE }')); ?></option>
						<option value="200"><?php echo ((isset($this->_rootref['L_FONT_HUGE'])) ? $this->_rootref['L_FONT_HUGE'] : ((isset($user->lang['FONT_HUGE'])) ? $user->lang['FONT_HUGE'] : '{ FONT_HUGE }')); ?></option>
					</select>
					<?php if (sizeof($this->_tpldata['custom_tags'])) {  ?>
						<br /><br />
						<?php $_custom_tags_count = (isset($this->_tpldata['custom_tags'])) ? sizeof($this->_tpldata['custom_tags']) : 0;if ($_custom_tags_count) {for ($_custom_tags_i = 0; $_custom_tags_i < $_custom_tags_count; ++$_custom_tags_i){$_custom_tags_val = &$this->_tpldata['custom_tags'][$_custom_tags_i]; ?>
							<input type="button" class="button2" name="addbbcode<?php echo $_custom_tags_val['BBCODE_ID']; ?>" value="<?php echo $_custom_tags_val['BBCODE_TAG']; ?>" onclick="bbstyle(<?php echo $_custom_tags_val['BBCODE_ID']; ?>)"<?php if ($_custom_tags_val['BBCODE_HELPLINE'] !== ('')) {  ?> onmouseover="helpline('cb_<?php echo $_custom_tags_val['BBCODE_ID']; ?>')" onmouseout="helpline('tip')"<?php } ?> />
						<?php }} } ?>
				</div>

				<p><input type="text" class="text full" style="border: 0; background: none;" name="helpbox" value="<?php echo ((isset($this->_rootref['L_STYLES_TIP'])) ? $this->_rootref['L_STYLES_TIP'] : ((isset($user->lang['STYLES_TIP'])) ? $user->lang['STYLES_TIP'] : '{ STYLES_TIP }')); ?>" /></p>

				<dl>
					<dt style="width: 90px;"><label for="lang_iso"><?php echo ((isset($this->_rootref['L_DONATION_DP_LANG'])) ? $this->_rootref['L_DONATION_DP_LANG'] : ((isset($user->lang['DONATION_DP_LANG'])) ? $user->lang['DONATION_DP_LANG'] : '{ DONATION_DP_LANG }')); ?></label></dt>
					<dd style="margin-<?php echo (isset($this->_rootref['S_CONTENT_FLOW_BEGIN'])) ? $this->_rootref['S_CONTENT_FLOW_BEGIN'] : ''; ?>: 90px;"><select id="lang_iso" name="lang_iso"><?php $_langs_count = (isset($this->_tpldata['langs'])) ? sizeof($this->_tpldata['langs']) : 0;if ($_langs_count) {for ($_langs_i = 0; $_langs_i < $_langs_count; ++$_langs_i){$_langs_val = &$this->_tpldata['langs'][$_langs_i]; ?><option value="<?php echo $_langs_val['ISO']; ?>"<?php if ($_langs_val['ISO'] == $this->_rootref['LANG_ISO']) {  ?> selected="selected" <?php } ?>><?php echo $_langs_val['NAME']; ?></option><?php }} ?></select></dd>

					<dt style="width: 90px;">
						<script type="text/javascript">
						// <![CDATA[
							colorPalette('v', 12, 10);
						// ]]>
						</script>
					</dt>
					<dd style="margin-<?php echo (isset($this->_rootref['S_CONTENT_FLOW_BEGIN'])) ? $this->_rootref['S_CONTENT_FLOW_BEGIN'] : ''; ?>: 90px;"><textarea name="input_pages" rows="10" cols="60" style="width: 95%;" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" onfocus="initInsertions();"><?php echo (isset($this->_rootref['DONATION_BODY'])) ? $this->_rootref['DONATION_BODY'] : ''; ?></textarea></dd>
					<dd style="margin-<?php echo (isset($this->_rootref['S_CONTENT_FLOW_BEGIN'])) ? $this->_rootref['S_CONTENT_FLOW_BEGIN'] : ''; ?>: 90px; margin-top: 5px;">
						<strong><?php echo ((isset($this->_rootref['L_SMILIES'])) ? $this->_rootref['L_SMILIES'] : ((isset($user->lang['SMILIES'])) ? $user->lang['SMILIES'] : '{ SMILIES }')); ?></strong><br />
						<?php $_smiley_count = (isset($this->_tpldata['smiley'])) ? sizeof($this->_tpldata['smiley']) : 0;if ($_smiley_count) {for ($_smiley_i = 0; $_smiley_i < $_smiley_count; ++$_smiley_i){$_smiley_val = &$this->_tpldata['smiley'][$_smiley_i]; ?>
							<a href="#" onclick="insert_text('<?php echo $_smiley_val['A_SMILEY_CODE']; ?>', true); return false;"><img src="<?php echo $_smiley_val['SMILEY_IMG']; ?>" width="<?php echo $_smiley_val['SMILEY_WIDTH']; ?>" height="<?php echo $_smiley_val['SMILEY_HEIGHT']; ?>" alt="<?php echo $_smiley_val['SMILEY_CODE']; ?>" title="<?php echo $_smiley_val['SMILEY_DESC']; ?>" /></a>
						<?php }} if ($this->_rootref['S_SHOW_SMILEY_LINK']) {  ?>
							<br /><a href="<?php echo (isset($this->_rootref['U_MORE_SMILIES'])) ? $this->_rootref['U_MORE_SMILIES'] : ''; ?>" onclick="popup(this.href, 300, 350, '_phpbbsmilies'); return false;"><?php echo ((isset($this->_rootref['L_MORE_SMILIES'])) ? $this->_rootref['L_MORE_SMILIES'] : ((isset($user->lang['MORE_SMILIES'])) ? $user->lang['MORE_SMILIES'] : '{ MORE_SMILIES }')); ?></a>
						<?php } ?>
					</dd>
				</dl>
			</fieldset>

			<fieldset>
				<p class="submit-buttons">
					<?php echo (isset($this->_rootref['S_HIDDEN_FIELDS'])) ? $this->_rootref['S_HIDDEN_FIELDS'] : ''; ?>
					<input class="button1" type="submit" id="submit" name="submit" value="<?php echo ((isset($this->_rootref['L_SUBMIT'])) ? $this->_rootref['L_SUBMIT'] : ((isset($user->lang['SUBMIT'])) ? $user->lang['SUBMIT'] : '{ SUBMIT }')); ?>" />&nbsp;
					<input class="button2" type="submit" name="preview" value="<?php echo ((isset($this->_rootref['L_PREVIEW'])) ? $this->_rootref['L_PREVIEW'] : ((isset($user->lang['PREVIEW'])) ? $user->lang['PREVIEW'] : '{ PREVIEW }')); ?>" />
				</p>
				<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>
			</fieldset>

			<table cellspacing="1">
				<caption><?php echo ((isset($this->_rootref['L_DONATION_DP_PREDEFINED_VARS'])) ? $this->_rootref['L_DONATION_DP_PREDEFINED_VARS'] : ((isset($user->lang['DONATION_DP_PREDEFINED_VARS'])) ? $user->lang['DONATION_DP_PREDEFINED_VARS'] : '{ DONATION_DP_PREDEFINED_VARS }')); ?></caption>
				<col class="col1" /><col class="col2" /><col class="col1" />

				<thead>
					<tr>
						<th><?php echo ((isset($this->_rootref['L_DONATION_DP_VAR_NAME'])) ? $this->_rootref['L_DONATION_DP_VAR_NAME'] : ((isset($user->lang['DONATION_DP_VAR_NAME'])) ? $user->lang['DONATION_DP_VAR_NAME'] : '{ DONATION_DP_VAR_NAME }')); ?></th>
						<th><?php echo ((isset($this->_rootref['L_DONATION_DP_VAR_VAR'])) ? $this->_rootref['L_DONATION_DP_VAR_VAR'] : ((isset($user->lang['DONATION_DP_VAR_VAR'])) ? $user->lang['DONATION_DP_VAR_VAR'] : '{ DONATION_DP_VAR_VAR }')); ?></th>
						<th><?php echo ((isset($this->_rootref['L_DONATION_DP_VAR_EXAMPLE'])) ? $this->_rootref['L_DONATION_DP_VAR_EXAMPLE'] : ((isset($user->lang['DONATION_DP_VAR_EXAMPLE'])) ? $user->lang['DONATION_DP_VAR_EXAMPLE'] : '{ DONATION_DP_VAR_EXAMPLE }')); ?></th>
					</tr>
				</thead>

				<tbody>
				<?php $_dp_vars_count = (isset($this->_tpldata['dp_vars'])) ? sizeof($this->_tpldata['dp_vars']) : 0;if ($_dp_vars_count) {for ($_dp_vars_i = 0; $_dp_vars_i < $_dp_vars_count; ++$_dp_vars_i){$_dp_vars_val = &$this->_tpldata['dp_vars'][$_dp_vars_i]; ?>
					<tr>
						<td><?php echo $_dp_vars_val['NAME']; ?></td>
						<td><a href="#" onclick="insert_text('<?php echo $_dp_vars_val['VARIABLE']; ?>'); return false;"><strong><?php echo $_dp_vars_val['VARIABLE']; ?></strong></a></td>
						<td><strong><em><?php echo $_dp_vars_val['EXAMPLE']; ?></em></strong></td>
					</tr>
				<?php }} ?>
				</tbody>
			</table>
		</form>
	<?php } else { ?>
	<h1><?php echo ((isset($this->_rootref['L_TITLE'])) ? $this->_rootref['L_TITLE'] : ((isset($user->lang['TITLE'])) ? $user->lang['TITLE'] : '{ TITLE }')); ?></h1>
	<p><?php echo ((isset($this->_rootref['L_TITLE_EXPLAIN'])) ? $this->_rootref['L_TITLE_EXPLAIN'] : ((isset($user->lang['TITLE_EXPLAIN'])) ? $user->lang['TITLE_EXPLAIN'] : '{ TITLE_EXPLAIN }')); ?></p>

		<form id="acp_donation" method="post" action="<?php echo (isset($this->_rootref['U_ACTION'])) ? $this->_rootref['U_ACTION'] : ''; ?>">
			<table cellspacing="1">
				<col class="row1" /><?php if (sizeof($this->_tpldata['langs'])) {  ?><col class="row1" /><?php } ?><col class="row2" /><col class="row2" />
				<thead>
					<tr>
						<th><?php echo ((isset($this->_rootref['L_DONATION_DP_PAGE'])) ? $this->_rootref['L_DONATION_DP_PAGE'] : ((isset($user->lang['DONATION_DP_PAGE'])) ? $user->lang['DONATION_DP_PAGE'] : '{ DONATION_DP_PAGE }')); ?></th>
						<th style="width: 5%; text-align: center;"><?php echo ((isset($this->_rootref['L_DONATION_DP_LANG'])) ? $this->_rootref['L_DONATION_DP_LANG'] : ((isset($user->lang['DONATION_DP_LANG'])) ? $user->lang['DONATION_DP_LANG'] : '{ DONATION_DP_LANG }')); ?></th>
						<th style="vertical-align: top; width: 50px; text-align: center; white-space: nowrap;"><?php echo ((isset($this->_rootref['L_ACTION'])) ? $this->_rootref['L_ACTION'] : ((isset($user->lang['ACTION'])) ? $user->lang['ACTION'] : '{ ACTION }')); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php $_langs_count = (isset($this->_tpldata['langs'])) ? sizeof($this->_tpldata['langs']) : 0;if ($_langs_count) {for ($_langs_i = 0; $_langs_i < $_langs_count; ++$_langs_i){$_langs_val = &$this->_tpldata['langs'][$_langs_i]; ?>
							<tr>
								<td class="row3" colspan="3"><?php echo $_langs_val['NAME']; ?></td>
							</tr>
					<?php $_dp_list_count = (isset($_langs_val['dp_list'])) ? sizeof($_langs_val['dp_list']) : 0;if ($_dp_list_count) {for ($_dp_list_i = 0; $_dp_list_i < $_dp_list_count; ++$_dp_list_i){$_dp_list_val = &$_langs_val['dp_list'][$_dp_list_i]; if (!($_dp_list_val['S_ROW_COUNT'] & 1)  ) {  ?><tr class="row1"><?php } else { ?><tr class="row2"><?php } ?>
							<td><a href="<?php echo $_dp_list_val['U_EDIT']; ?>"><?php echo $_dp_list_val['DP_TITLE']; ?></a></td>
							<td style="text-align: center;"><?php echo $_dp_list_val['DP_LANG']; ?></td>
							<td style="text-align: center;"><a href="<?php echo $_dp_list_val['U_EDIT']; ?>"><?php echo (isset($this->_rootref['ICON_EDIT'])) ? $this->_rootref['ICON_EDIT'] : ''; ?></a>&nbsp;<a href="<?php echo $_dp_list_val['U_DELETE']; ?>"><?php echo (isset($this->_rootref['ICON_DELETE'])) ? $this->_rootref['ICON_DELETE'] : ''; ?></a></td>
						</tr>
					<?php }} else { ?>
						<tr class="row2">
							<td style="text-align: center;" colspan="3"><?php echo ((isset($this->_rootref['L_ACP_NO_ITEMS'])) ? $this->_rootref['L_ACP_NO_ITEMS'] : ((isset($user->lang['ACP_NO_ITEMS'])) ? $user->lang['ACP_NO_ITEMS'] : '{ ACP_NO_ITEMS }')); ?></td>
						</tr>
					<?php } }} ?>
				</tbody>
			</table>
			<fieldset class="quick">
				<select id="donation_name" name="donation_name">
					<option value="donation_body" selected="selected"><?php echo ((isset($this->_rootref['L_DONATION_BODY'])) ? $this->_rootref['L_DONATION_BODY'] : ((isset($user->lang['DONATION_BODY'])) ? $user->lang['DONATION_BODY'] : '{ DONATION_BODY }')); ?></option>
					<option value="donation_success"><?php echo ((isset($this->_rootref['L_DONATION_SUCCESS'])) ? $this->_rootref['L_DONATION_SUCCESS'] : ((isset($user->lang['DONATION_SUCCESS'])) ? $user->lang['DONATION_SUCCESS'] : '{ DONATION_SUCCESS }')); ?></option>
					<option value="donation_cancel"><?php echo ((isset($this->_rootref['L_DONATION_CANCEL'])) ? $this->_rootref['L_DONATION_CANCEL'] : ((isset($user->lang['DONATION_CANCEL'])) ? $user->lang['DONATION_CANCEL'] : '{ DONATION_CANCEL }')); ?></option>
				</select>
				<input  type="hidden" name="action" value="add" />
				<input class="button1" type="submit" name="add" value="<?php echo ((isset($this->_rootref['L_ADD'])) ? $this->_rootref['L_ADD'] : ((isset($user->lang['ADD'])) ? $user->lang['ADD'] : '{ ADD }')); ?>" />

				<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>
			</fieldset>
		</form>

		<div class="clearfix">&nbsp;</div><br style="clear: both;" />
	<?php } } if ($this->_rootref['S_CURRENCY']) {  if ($this->_rootref['S_EDIT']) {  ?>
		<a href="<?php echo (isset($this->_rootref['U_BACK'])) ? $this->_rootref['U_BACK'] : ''; ?>" style="float: <?php echo (isset($this->_rootref['S_CONTENT_FLOW_END'])) ? $this->_rootref['S_CONTENT_FLOW_END'] : ''; ?>;">&laquo; <?php echo ((isset($this->_rootref['L_BACK'])) ? $this->_rootref['L_BACK'] : ((isset($user->lang['BACK'])) ? $user->lang['BACK'] : '{ BACK }')); ?></a>

		<h1><?php echo ((isset($this->_rootref['L_TITLE'])) ? $this->_rootref['L_TITLE'] : ((isset($user->lang['TITLE'])) ? $user->lang['TITLE'] : '{ TITLE }')); ?></h1>

		<p><?php echo ((isset($this->_rootref['L_TITLE_EXPLAIN'])) ? $this->_rootref['L_TITLE_EXPLAIN'] : ((isset($user->lang['TITLE_EXPLAIN'])) ? $user->lang['TITLE_EXPLAIN'] : '{ TITLE_EXPLAIN }')); ?></p>

		<form id="acp_donation" method="post" action="<?php echo (isset($this->_rootref['U_ACTION'])) ? $this->_rootref['U_ACTION'] : ''; ?>">
			<fieldset>
				<legend><?php echo ((isset($this->_rootref['L_GENERAL_OPTIONS'])) ? $this->_rootref['L_GENERAL_OPTIONS'] : ((isset($user->lang['GENERAL_OPTIONS'])) ? $user->lang['GENERAL_OPTIONS'] : '{ GENERAL_OPTIONS }')); ?></legend>
				<dl>
					<dt><label for="item_name"><?php echo ((isset($this->_rootref['L_DONATION_DC_NAME'])) ? $this->_rootref['L_DONATION_DC_NAME'] : ((isset($user->lang['DONATION_DC_NAME'])) ? $user->lang['DONATION_DC_NAME'] : '{ DONATION_DC_NAME }')); ?>:</label><br /><span><?php echo ((isset($this->_rootref['L_DONATION_DC_NAME_EXPLAIN'])) ? $this->_rootref['L_DONATION_DC_NAME_EXPLAIN'] : ((isset($user->lang['DONATION_DC_NAME_EXPLAIN'])) ? $user->lang['DONATION_DC_NAME_EXPLAIN'] : '{ DONATION_DC_NAME_EXPLAIN }')); ?></span></dt>
					<dd><input id="item_name" name="item_name" type="text" class="text medium" value="<?php echo (isset($this->_rootref['ITEM_NAME'])) ? $this->_rootref['ITEM_NAME'] : ''; ?>" /></dd>
				</dl>
				<dl>
					<dt><label for="item_iso_code"><?php echo ((isset($this->_rootref['L_DONATION_DC_ISO_CODE'])) ? $this->_rootref['L_DONATION_DC_ISO_CODE'] : ((isset($user->lang['DONATION_DC_ISO_CODE'])) ? $user->lang['DONATION_DC_ISO_CODE'] : '{ DONATION_DC_ISO_CODE }')); ?>:</label><br /><span><?php echo ((isset($this->_rootref['L_DONATION_DC_ISO_CODE_EXPLAIN'])) ? $this->_rootref['L_DONATION_DC_ISO_CODE_EXPLAIN'] : ((isset($user->lang['DONATION_DC_ISO_CODE_EXPLAIN'])) ? $user->lang['DONATION_DC_ISO_CODE_EXPLAIN'] : '{ DONATION_DC_ISO_CODE_EXPLAIN }')); ?></span></dt>
					<dd><input id="item_iso_code" name="item_iso_code" type="text" class="text medium" value="<?php echo (isset($this->_rootref['ITEM_ISO_CODE'])) ? $this->_rootref['ITEM_ISO_CODE'] : ''; ?>" /></dd>
				</dl>
				<dl>
					<dt><label for="item_symbol"><?php echo ((isset($this->_rootref['L_DONATION_DC_SYMBOL'])) ? $this->_rootref['L_DONATION_DC_SYMBOL'] : ((isset($user->lang['DONATION_DC_SYMBOL'])) ? $user->lang['DONATION_DC_SYMBOL'] : '{ DONATION_DC_SYMBOL }')); ?>:</label><br /><span><?php echo ((isset($this->_rootref['L_DONATION_DC_SYMBOL_EXPLAIN'])) ? $this->_rootref['L_DONATION_DC_SYMBOL_EXPLAIN'] : ((isset($user->lang['DONATION_DC_SYMBOL_EXPLAIN'])) ? $user->lang['DONATION_DC_SYMBOL_EXPLAIN'] : '{ DONATION_DC_SYMBOL_EXPLAIN }')); ?></span></dt>
					<dd><input id="item_symbol" name="item_symbol" type="text" class="text medium" value="<?php echo (isset($this->_rootref['ITEM_SYMBOL'])) ? $this->_rootref['ITEM_SYMBOL'] : ''; ?>" /></dd>
				</dl>
				<hr />
				<div id="itemoptions">
					<dl>
						<dt><label for="item_enable"><?php echo ((isset($this->_rootref['L_DONATION_DC_ENABLED'])) ? $this->_rootref['L_DONATION_DC_ENABLED'] : ((isset($user->lang['DONATION_DC_ENABLED'])) ? $user->lang['DONATION_DC_ENABLED'] : '{ DONATION_DC_ENABLED }')); ?>:</label><br /><span><?php echo ((isset($this->_rootref['L_DONATION_DC_ENABLED_EXPLAIN'])) ? $this->_rootref['L_DONATION_DC_ENABLED_EXPLAIN'] : ((isset($user->lang['DONATION_DC_ENABLED_EXPLAIN'])) ? $user->lang['DONATION_DC_ENABLED_EXPLAIN'] : '{ DONATION_DC_ENABLED_EXPLAIN }')); ?></span></dt>
						<dd><label><input id="item_enable" name="item_enable" type="radio" class="radio" value="1"<?php if ($this->_rootref['ITEM_ENABLED']) {  ?> checked="checked"<?php } ?> /> <?php echo ((isset($this->_rootref['L_YES'])) ? $this->_rootref['L_YES'] : ((isset($user->lang['YES'])) ? $user->lang['YES'] : '{ YES }')); ?></label>
							<label><input  name="item_enable" type="radio" class="radio" value="0"<?php if (! $this->_rootref['ITEM_ENABLED']) {  ?> checked="checked"<?php } ?> /> <?php echo ((isset($this->_rootref['L_NO'])) ? $this->_rootref['L_NO'] : ((isset($user->lang['NO'])) ? $user->lang['NO'] : '{ NO }')); ?></label></dd>
					</dl>
				</div>

			</fieldset>
			<fieldset>
				<p class="submit-buttons">
					<?php echo (isset($this->_rootref['S_HIDDEN_FIELDS'])) ? $this->_rootref['S_HIDDEN_FIELDS'] : ''; ?>
					<input class="button1" type="submit" id="submit" name="update" value="<?php echo ((isset($this->_rootref['L_SUBMIT'])) ? $this->_rootref['L_SUBMIT'] : ((isset($user->lang['SUBMIT'])) ? $user->lang['SUBMIT'] : '{ SUBMIT }')); ?>" />&nbsp;
					<input class="button2" type="reset" id="reset" name="reset" value="<?php echo ((isset($this->_rootref['L_RESET'])) ? $this->_rootref['L_RESET'] : ((isset($user->lang['RESET'])) ? $user->lang['RESET'] : '{ RESET }')); ?>" />
					<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>
				</p>
			</fieldset>
		</form>

	<?php } else { ?>
		<h1><?php echo ((isset($this->_rootref['L_TITLE'])) ? $this->_rootref['L_TITLE'] : ((isset($user->lang['TITLE'])) ? $user->lang['TITLE'] : '{ TITLE }')); ?></h1>

		<p><?php echo ((isset($this->_rootref['L_TITLE_EXPLAIN'])) ? $this->_rootref['L_TITLE_EXPLAIN'] : ((isset($user->lang['TITLE_EXPLAIN'])) ? $user->lang['TITLE_EXPLAIN'] : '{ TITLE_EXPLAIN }')); ?></p>

		<form id="acp_donation" method="post" action="<?php echo (isset($this->_rootref['U_ACTION'])) ? $this->_rootref['U_ACTION'] : ''; ?>">
			<table cellspacing="1">
				<thead>
					<tr>
						<th colspan="1"><?php echo ((isset($this->_rootref['L_NAME'])) ? $this->_rootref['L_NAME'] : ((isset($user->lang['NAME'])) ? $user->lang['NAME'] : '{ NAME }')); ?></th>
						<th colspan="2"><?php echo ((isset($this->_rootref['L_OPTIONS'])) ? $this->_rootref['L_OPTIONS'] : ((isset($user->lang['OPTIONS'])) ? $user->lang['OPTIONS'] : '{ OPTIONS }')); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php $_items_count = (isset($this->_tpldata['items'])) ? sizeof($this->_tpldata['items']) : 0;if ($_items_count) {for ($_items_i = 0; $_items_i < $_items_count; ++$_items_i){$_items_val = &$this->_tpldata['items'][$_items_i]; if (!($_items_val['S_ROW_COUNT'] & 1)  ) {  ?><tr class="row1"><?php } else { ?><tr class="row2"><?php } ?>
						<td><a href="<?php echo $_items_val['U_EDIT']; ?>"><?php echo $_items_val['ITEM_NAME']; ?></a></td>
						<td style="width: 15%; white-space: nowrap; text-align: center; vertical-align: middle;">&nbsp;<?php if ($_items_val['ITEM_ENABLED']) {  ?><a href="<?php echo $_items_val['U_DISABLE']; ?>"><?php echo ((isset($this->_rootref['L_DISABLE'])) ? $this->_rootref['L_DISABLE'] : ((isset($user->lang['DISABLE'])) ? $user->lang['DISABLE'] : '{ DISABLE }')); ?></a><?php } else { ?><a href="<?php echo $_items_val['U_ENABLE']; ?>"><?php echo ((isset($this->_rootref['L_ENABLE'])) ? $this->_rootref['L_ENABLE'] : ((isset($user->lang['ENABLE'])) ? $user->lang['ENABLE'] : '{ ENABLE }')); ?></a><?php } ?>&nbsp;</td>
						<td style="width:90px; white-space: nowrap; text-align: right; vertical-align: middle;">
							<?php if ($_items_val['S_FIRST_ROW'] && ! $_items_val['S_LAST_ROW'] && ! $this->_rootref['S_MODE']) {  ?>
								<?php echo (isset($this->_rootref['ICON_MOVE_UP_DISABLED'])) ? $this->_rootref['ICON_MOVE_UP_DISABLED'] : ''; ?>
								<a href="<?php echo $_items_val['U_MOVE_DOWN']; ?>"><?php echo (isset($this->_rootref['ICON_MOVE_DOWN'])) ? $this->_rootref['ICON_MOVE_DOWN'] : ''; ?></a>
							<?php } else if (! $_items_val['S_FIRST_ROW'] && ! $_items_val['S_LAST_ROW'] && ! $this->_rootref['S_MODE']) {  ?>
								<a href="<?php echo $_items_val['U_MOVE_UP']; ?>"><?php echo (isset($this->_rootref['ICON_MOVE_UP'])) ? $this->_rootref['ICON_MOVE_UP'] : ''; ?></a> 
								<a href="<?php echo $_items_val['U_MOVE_DOWN']; ?>"><?php echo (isset($this->_rootref['ICON_MOVE_DOWN'])) ? $this->_rootref['ICON_MOVE_DOWN'] : ''; ?></a> 
							<?php } else if ($_items_val['S_LAST_ROW'] && ! $_items_val['S_FIRST_ROW'] && ! $this->_rootref['S_MODE']) {  ?>
								<a href="<?php echo $_items_val['U_MOVE_UP']; ?>"><?php echo (isset($this->_rootref['ICON_MOVE_UP'])) ? $this->_rootref['ICON_MOVE_UP'] : ''; ?></a>	
								<?php echo (isset($this->_rootref['ICON_MOVE_DOWN_DISABLED'])) ? $this->_rootref['ICON_MOVE_DOWN_DISABLED'] : ''; ?>
							<?php } else { ?>
								<?php echo (isset($this->_rootref['ICON_MOVE_UP_DISABLED'])) ? $this->_rootref['ICON_MOVE_UP_DISABLED'] : ''; ?>
								<?php echo (isset($this->_rootref['ICON_MOVE_DOWN_DISABLED'])) ? $this->_rootref['ICON_MOVE_DOWN_DISABLED'] : ''; ?>
							<?php } ?>
							<a href="<?php echo $_items_val['U_EDIT']; ?>"><?php echo (isset($this->_rootref['ICON_EDIT'])) ? $this->_rootref['ICON_EDIT'] : ''; ?></a> 
							<a href="<?php echo $_items_val['U_DELETE']; ?>"><?php echo (isset($this->_rootref['ICON_DELETE'])) ? $this->_rootref['ICON_DELETE'] : ''; ?></a>
						</td>
					</tr>
				<?php }} else { ?>
					<tr class="row2">
						<td style="text-align: center;" colspan="3"><?php echo ((isset($this->_rootref['L_ACP_NO_ITEMS'])) ? $this->_rootref['L_ACP_NO_ITEMS'] : ((isset($user->lang['ACP_NO_ITEMS'])) ? $user->lang['ACP_NO_ITEMS'] : '{ ACP_NO_ITEMS }')); ?></td>
					</tr>
				<?php } ?>
				</tbody>
			</table>

			<div class="clearfix">&nbsp;</div>

			<fieldset class="quick" style="float: <?php echo (isset($this->_rootref['S_CONTENT_FLOW_END'])) ? $this->_rootref['S_CONTENT_FLOW_END'] : ''; ?>;">
				<?php echo (isset($this->_rootref['S_HIDDEN_FIELDS'])) ? $this->_rootref['S_HIDDEN_FIELDS'] : ''; ?>
				<input class="button2" name="add" type="submit" value="<?php echo ((isset($this->_rootref['L_CREATE_ITEM'])) ? $this->_rootref['L_CREATE_ITEM'] : ((isset($user->lang['CREATE_ITEM'])) ? $user->lang['CREATE_ITEM'] : '{ CREATE_ITEM }')); ?>" />
				<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>
			</fieldset>
		</form>

		<div class="clearfix">&nbsp;</div><br style="clear: both;" />
	<?php } } $this->_tpl_include('overall_footer.html'); ?>